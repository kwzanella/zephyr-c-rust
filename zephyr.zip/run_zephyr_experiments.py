"""Run existing Zephyr cases without modifying application sources.

Build times are incremental observations, NOT comparable clean-build timings.
Each runtime starts a new QEMU process, stops at the first 2000-attempt
consumer summary or a reported halt, and has a 120-second wall timeout.
Only processes launched here may be stopped by this script.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import queue
import re
import shutil
import subprocess
import threading
import time

ROOT = Path(r"D:\Zephyr")
OUT = ROOT / "results" / ("batch-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))
OUT.mkdir(parents=True, exist_ok=False)
ENV = os.environ.copy()
ENV.update(CARGO_HOME=str(ROOT / "tools/rust/cargo"),
           RUSTUP_HOME=str(ROOT / "tools/rust/rustup"),
           ZEPHYR_SDK_INSTALL_DIR=str(ROOT / "tools/zephyr-sdk-1.0.1"),
           LIBCLANG_PATH=str(ROOT / "tools/winlibs/mingw64/bin"),
           TEMP=str(ROOT / "temp"), TMP=str(ROOT / "temp"))
ENV["PATH"] = ";".join([str(ROOT / p) for p in [
    "tools/rust/cargo/bin", ".venv/Scripts", "tools/cmake-3.31.12-windows-x86_64/bin",
    "tools/ninja", "tools/winlibs/mingw64/bin"]] +
    [r"D:\Program Files\Git\mingw64\bin", ENV.get("PATH", "")])
WEST = str(ROOT / ".venv/Scripts/west.exe")
QEMU = str(ROOT / "tools/zephyr-sdk-1.0.1/hosttools/qemu/qemu-system-arm.exe")
CASES = [
    ("baseline-c", "c"), ("baseline-rust", "rust"),
    ("fault-use-after-free-c-control", "fault-use-after-free/c-control"),
    ("fault-uninitialized-pointer-c", "fault-uninitialized-pointer/c"),
    ("fault-uninitialized-pointer-rust", "fault-uninitialized-pointer/rust"),
    ("fault-out-of-bounds-c", "fault-out-of-bounds/c"),
    ("fault-out-of-bounds-rust", "fault-out-of-bounds/rust"),
    ("fault-use-after-free-c", "fault-use-after-free/c"),
    ("fault-use-after-free-rust", "fault-use-after-free/rust"),
]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save_json(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")

def bounded_command(command, log, timeout=300):
    start = time.perf_counter()
    with log.open("wb") as stream:
        process = subprocess.Popen(command, cwd=ROOT / "workspace", env=ENV,
                                   stdout=stream, stderr=subprocess.STDOUT,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        timed_out = False
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            code = process.wait()
    return dict(command=command, exit_code=code, timeout=timed_out,
                wall_seconds=round(time.perf_counter() - start, 3), log=str(log))

def runtime(case_dir, elf, number):
    log = case_dir / f"run-{number:02d}.log"
    cmd = [QEMU, "-cpu", "cortex-m3", "-machine", "lm3s6965evb", "-net", "none",
           "-pidfile", str(case_dir / f"qemu-{number:02d}.pid"),
           "-chardev", "stdio,id=con,mux=on", "-serial", "chardev:con",
           "-mon", "chardev=con,mode=readline", "-nographic",
           "-icount", "shift=6,align=off,sleep=off", "-rtc", "clock=vm",
           "-kernel", str(elf)]
    start = time.perf_counter()
    p = subprocess.Popen(cmd, cwd=case_dir, env=ENV, stdin=subprocess.PIPE,
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         creationflags=subprocess.CREATE_NO_WINDOW)
    lines = queue.Queue()
    def read():
        for line in iter(p.stdout.readline, b""):
            lines.put(line)
        lines.put(None)
    threading.Thread(target=read, daemon=True).start()
    text = ""
    stop = None
    with log.open("wb") as stream:
        while time.perf_counter() - start < 120:
            try:
                line = lines.get(timeout=0.25)
            except queue.Empty:
                continue
            if line is None:
                stop = "process_exit"
                break
            stream.write(line)
            stream.flush()
            decoded = line.decode("utf-8", errors="replace")
            text += decoded
            if "Halting system" in decoded:
                stop = "reported_system_halt"
                break
            m = re.search(r"attempts: (\d+), accepted:.*on time: \d+", decoded)
            if m and int(m.group(1)) >= 2000:
                stop = "message_limit"
                break
        stop = stop or "wall_timeout"
        # Stop QEMU only after the observation window; this is not a guest crash.
        forced = False
        if p.poll() is None:
            try:
                p.stdin.write(b"\x01x")
                p.stdin.flush()
                p.wait(timeout=5)
            except (OSError, subprocess.TimeoutExpired):
                forced = True
                p.kill()
                p.wait()
        while True:
            try:
                line = lines.get(timeout=0.25)
            except queue.Empty:
                break
            if line is None:
                break
            stream.write(line)
            text += line.decode("utf-8", errors="replace")
    consumers = list(re.finditer(
        r"attempts: (\d+), accepted: (\d+), receive err: (\d+), checksum err: (\d+), "
        r"sequence err: (\d+), deadline misses: (\d+), on time: (\d+)", text))
    fields = ["attempts", "accepted", "receive_errors", "checksum_errors",
              "sequence_errors", "deadline_misses", "on_time"]
    counters = dict(zip(fields, map(int, consumers[-1].groups()))) if consumers else None
    producer = list(re.finditer(r"emitted: (\d+), queue-full drops: (\d+), channel err: (\d+)", text))
    if producer:
        prod = dict(zip(["emitted", "queue_full_drops", "channel_errors"], map(int, producer[-1].groups())))
    else:
        prod = list(re.finditer(r"emitted: (\d+), send errors: (\d+)", text))
        prod = dict(zip(["emitted", "send_errors"], map(int, prod[-1].groups()))) if prod else None
    if "index out of bounds" in text and "Halting system" in text:
        outcome = "bounds_check_panic_and_system_halt"
    elif stop == "message_limit" and counters:
        outcome = "observed_counter_errors" if any(counters[k] for k in fields[2:6]) else "no_observable_counter_error"
    else:
        outcome = stop
    return dict(repetition=number, command=cmd, outcome=outcome, stop_reason=stop,
                guest_fault_markers=re.findall(r"(?:FAULT|CONTROL)[^\r\n]*", text),
                counters=counters, producer_counters=prod, exit_code=p.returncode,
                harness_forced_kill=forced, wall_seconds=round(time.perf_counter()-start,3),
                log=str(log), log_sha256=digest(log))

manifest = dict(started=datetime.datetime.now().astimezone().isoformat(),
                output=str(OUT), repetitions=3, message_limit=2000, wall_timeout_seconds=120,
                build_mode="existing directories, incremental; NOT clean-build timing",
                scope="single-machine QEMU runs; no application source edits",
                caveat="No symptom is not proof of memory safety or of an optimized UB access executing.",
                cases=[])
save_json(OUT / "results.json", manifest)
print("RESULTS " + str(OUT), flush=True)
for tool, command in [
    ("rustc", [str(ROOT / "tools/rust/cargo/bin/rustc.exe"), "-Vv"]),
    ("cargo", [str(ROOT / "tools/rust/cargo/bin/cargo.exe"), "--version"]),
    ("qemu", [QEMU, "--version"]),
    ("west", [WEST, "--version"]),
    ("cmake", [str(ROOT / "tools/cmake-3.31.12-windows-x86_64/bin/cmake.exe"), "--version"]),
    ("ninja", [str(ROOT / "tools/ninja/ninja.exe"), "--version"]),
    ("zephyr-commit", ["git", "-C", str(ROOT / "workspace/zephyr"), "rev-parse", "HEAD"]),
]:
    bounded_command(command, OUT / (tool + "-version.log"), 30)

for name, relative in CASES:
    case_dir = OUT / name
    case_dir.mkdir()
    app = ROOT / "apps" / relative
    source_hashes = {str(p.relative_to(app)): digest(p) for p in app.rglob("*")
                     if p.is_file() and (p.suffix in (".c", ".rs", ".conf", ".toml")
                                         or p.name in ("CMakeLists.txt", "Cargo.lock"))
                     and "target" not in p.parts}
    entry = dict(name=name, app=str(app), source_sha256=source_hashes, builds=[], runs=[])
    manifest["cases"].append(entry)
    command = [WEST, "build", "-b", "qemu_cortex_m3", str(app), "-d", str(ROOT / "build" / name)]
    print("BUILD " + name, flush=True)
    result = bounded_command(command, case_dir / "build-01.log")
    entry["builds"].append(result)
    content = Path(result["log"]).read_text(encoding="utf-8", errors="replace")
    if result["exit_code"] != 0:
        codes = sorted(set(re.findall(r"error\[(E\d+)\]", content)))
        entry["compiler_errors"] = codes
        expected = "E0381" if name == "fault-uninitialized-pointer-rust" else "E0382" if name == "fault-use-after-free-rust" else None
        entry["outcome"] = "compile_time_prevention" if expected and expected in codes else "build_failure_not_classified_as_prevention"
        if entry["outcome"] == "compile_time_prevention":
            for n in (2, 3):
                result = bounded_command(command, case_dir / f"build-{n:02d}.log")
                entry["builds"].append(result)
                check = Path(result["log"]).read_text(encoding="utf-8", errors="replace")
                if result["exit_code"] == 0 or f"error[{expected}]" not in check:
                    entry["outcome"] = "inconsistent_build_results"
        print(name + " " + entry["outcome"] + " " + str(codes), flush=True)
    else:
        build = ROOT / "build" / name
        elf = build / "zephyr/zephyr.elf"
        entry["elf_sha256"] = digest(elf)
        entry["memory_regions"] = re.findall(r"^\s*(FLASH|RAM):\s*(\d+) B\s+(\d+) KB\s+([\d.]+)%", content, re.M)
        for rel in ("zephyr/.config", "zephyr/zephyr.dts", "CMakeCache.txt", "zephyr/zephyr.map"):
            path = build / rel
            if path.exists():
                shutil.copy2(path, case_dir / path.name)
        for n in (1, 2, 3):
            print(f"RUN {name} {n}/3", flush=True)
            run = runtime(case_dir, elf, n)
            entry["runs"].append(run)
            print(name + " " + run["outcome"] + " " + str(run["counters"]), flush=True)
            save_json(OUT / "results.json", manifest)
    entry["sources_unchanged"] = all(digest(app / rel) == sha for rel, sha in source_hashes.items())
    save_json(OUT / "results.json", manifest)

manifest["finished"] = datetime.datetime.now().astimezone().isoformat()
save_json(OUT / "results.json", manifest)
rows = ["# Experiment results", "", "| Case | Build exit codes | Runtime results |", "|---|---|---|"]
for case in manifest["cases"]:
    builds = ", ".join(str(b["exit_code"]) for b in case["builds"])
    runs = "; ".join(f"{r['repetition']}: {r['outcome']} {r['counters']}" for r in case["runs"])
    rows.append(f"| {case['name']} | {builds} | {runs or case.get('outcome', '')} |")
rows += ["", "Build timings are incremental, not clean-build comparisons.",
         "Each runtime uses a fresh QEMU process. Harness termination is not a guest crash.",
         "No observable symptom does not establish memory safety."]
(OUT / "summary.md").write_text("\n".join(rows) + "\n", encoding="utf-8")
print("FINISHED " + str(OUT), flush=True)
